# AI Toolkit Remote 1.0

Нативное iPhone-приложение для управления **ostris/ai-toolkit** на Windows через существующий **PCRemoteServer 6.x**.

## Что уже есть

- Dashboard: статус AI Toolkit, запуск на ПК, GPU/VRAM/температура, активные задания.
- Jobs: все/активные задания, progress/steps/speed/info; создание нового job из JSON-конфига.
- Job detail: Start, Stop, Save now, live log с offset, loss chart, samples, список `.safetensors`, скачивание/Share Sheet.
- Создание нового job через вставку/импорт JSON и редактор существующего `job_config` + GPU IDs прямо с iPhone.
- Datasets: список, создание папки, просмотр изображений, массовая загрузка фото из галереи iPhone.
- Settings: адрес PCRemoteServer, optional access key, refresh interval.
- AI Toolkit остаётся локальным на `127.0.0.1:8675`.

## Windows bridge

Файл `windows/aitoolkit_bridge.py` не заменяет существующий ComfyUI server API. Он занимает только `/api/aitk/*`.

Скопируйте:

- `aitoolkit_bridge.py` -> рядом с `windows/server.py`;
- `aitoolkit_remote.example.json` -> рядом с собранным `PCRemoteServer.exe`, переименовать в `aitoolkit_remote.json` и указать путь к вашему AI Toolkit.

Точные 3 вставки в `server.py` находятся в `windows/SERVER_INTEGRATION.txt`.

## iOS сборка

Проект использует XcodeGen, поэтому `.xcodeproj` генерируется автоматически:

```bash
cd ios
brew install xcodegen
xcodegen generate
open AIToolkitRemote.xcodeproj
```

Для GitHub Actions используйте `.github/workflows/build.yml`. Он собирает unsigned IPA для последующей подписи вашим sideloader/signer.

## API bridge

Основные маршруты:

- `GET /api/aitk/status`
- `POST /api/aitk/launch`
- `GET /api/aitk/gpu`
- `GET /api/aitk/jobs`
- `GET /api/aitk/jobs/{id}`
- `POST /api/aitk/jobs/{id}/start`
- `POST /api/aitk/jobs/{id}/stop`
- `POST /api/aitk/jobs/{id}/save`
- `POST /api/aitk/jobs/{id}/delete`
- `GET /api/aitk/jobs/{id}/log?offset=N`
- `GET /api/aitk/jobs/{id}/loss`
- `GET /api/aitk/jobs/{id}/samples`
- `GET /api/aitk/jobs/{id}/files`
- datasets list/create/listImages/upload
- protected media/file proxy through AI Toolkit's own allowed-root checks.

## Важно

Проверка авторизации текущего PCRemoteServer должна выполняться **до** `handle_aitoolkit_request`. Не выставляйте `8675` наружу: bridge специально принимает upstream только `localhost/127.0.0.1/::1`.
