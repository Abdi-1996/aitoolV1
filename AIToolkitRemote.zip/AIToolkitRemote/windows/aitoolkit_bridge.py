"""AI Toolkit bridge for PCRemoteServer 6.x.

Drop this file next to windows/server.py and call:

    from aitoolkit_bridge import handle_aitoolkit_request

at the beginning of do_GET/do_POST/do_DELETE:

    if handle_aitoolkit_request(self, 'GET'): return

The bridge deliberately exposes only a small whitelist under /api/aitk/ and keeps
AI Toolkit itself bound to localhost:8675.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple

PREFIX = "/api/aitk"


def _runtime_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


@dataclass
class BridgeConfig:
    base_url: str = "http://127.0.0.1:8675"
    start_command: str = ""
    start_cwd: str = ""
    request_timeout: float = 12.0

    @classmethod
    def load(cls) -> "BridgeConfig":
        path = _runtime_dir() / "aitoolkit_remote.json"
        if not path.exists():
            return cls()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            base = str(raw.get("base_url", cls.base_url)).rstrip("/")
            # Never allow the config to accidentally turn this bridge into an open proxy.
            parsed = urllib.parse.urlsplit(base)
            if parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
                base = cls.base_url
            return cls(
                base_url=base,
                start_command=str(raw.get("start_command", "")),
                start_cwd=str(raw.get("start_cwd", "")),
                request_timeout=float(raw.get("request_timeout", 12.0)),
            )
        except Exception:
            return cls()


_CONFIG = BridgeConfig.load()
_LAUNCH_LOCK = threading.Lock()
_LAST_LAUNCH = 0.0


def reload_aitoolkit_config() -> None:
    global _CONFIG
    _CONFIG = BridgeConfig.load()


def _send(handler, status: int, body: bytes, content_type: str = "application/json", extra: Optional[Dict[str, str]] = None) -> None:
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    if extra:
        for key, value in extra.items():
            if key.lower() in {"transfer-encoding", "connection", "content-length", "content-type"}:
                continue
            handler.send_header(key, value)
    handler.end_headers()
    if getattr(handler, "command", "GET") != "HEAD":
        handler.wfile.write(body)


def _json(handler, status: int, obj) -> None:
    _send(handler, status, json.dumps(obj, ensure_ascii=False).encode("utf-8"))


def _read_body(handler) -> bytes:
    try:
        length = int(handler.headers.get("Content-Length", "0") or "0")
    except ValueError:
        length = 0
    if length <= 0:
        return b""
    # Dataset uploads can be sizeable. Keep a hard upper limit to avoid accidental OOM.
    max_len = 512 * 1024 * 1024
    if length > max_len:
        raise ValueError("request too large")
    return handler.rfile.read(length)


def _upstream(method: str, path: str, body: bytes = b"", headers: Optional[Dict[str, str]] = None, timeout: Optional[float] = None) -> Tuple[int, bytes, Dict[str, str]]:
    url = _CONFIG.base_url + path
    req_headers = {"Accept": "application/json, image/*, video/*, application/octet-stream"}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, data=(body if method in {"POST", "PUT", "PATCH"} else None), method=method, headers=req_headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout or _CONFIG.request_timeout) as resp:
            data = resp.read()
            return resp.status, data, dict(resp.headers.items())
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers.items())


def _proxy(handler, upstream_method: str, upstream_path: str, body: bytes = b"", content_type: Optional[str] = None, binary: bool = False) -> None:
    headers: Dict[str, str] = {}
    if content_type:
        headers["Content-Type"] = content_type
    try:
        status, data, resp_headers = _upstream(upstream_method, upstream_path, body=body, headers=headers)
        ctype = resp_headers.get("Content-Type", "application/octet-stream" if binary else "application/json")
        passthrough = {}
        for key in ("Content-Disposition", "ETag", "Last-Modified", "Accept-Ranges", "Content-Range"):
            if key in resp_headers:
                passthrough[key] = resp_headers[key]
        _send(handler, status, data, ctype, passthrough)
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
        _json(handler, 503, {"ok": False, "error": "AI Toolkit is offline", "detail": str(e)})



def _proxy_stream(handler, upstream_path: str) -> None:
    """Stream a potentially large AI Toolkit file without buffering it in RAM."""
    url = _CONFIG.base_url + upstream_path
    headers = {"Accept": "*/*"}
    for key in ("Range", "If-None-Match", "If-Modified-Since"):
        value = handler.headers.get(key)
        if value:
            headers[key] = value
    req = urllib.request.Request(url, method="GET", headers=headers)
    try:
        try:
            resp = urllib.request.urlopen(req, timeout=max(_CONFIG.request_timeout, 60.0))
        except urllib.error.HTTPError as e:
            resp = e
        with resp:
            status = getattr(resp, "status", None) or getattr(resp, "code", 502)
            resp_headers = dict(resp.headers.items())
            ctype = resp_headers.get("Content-Type", "application/octet-stream")
            handler.send_response(status)
            handler.send_header("Content-Type", ctype)
            for key in ("Content-Length", "Content-Disposition", "ETag", "Last-Modified", "Accept-Ranges", "Content-Range", "Cache-Control"):
                value = resp_headers.get(key)
                if value is not None:
                    handler.send_header(key, value)
            handler.end_headers()
            if getattr(handler, "command", "GET") == "HEAD":
                return
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                handler.wfile.write(chunk)
    except (BrokenPipeError, ConnectionResetError):
        # The iPhone cancelled a download; nothing else to send.
        return
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
        try:
            _json(handler, 503, {"ok": False, "error": "AI Toolkit is offline", "detail": str(e)})
        except Exception:
            return

def _is_online() -> bool:
    try:
        status, _, _ = _upstream("GET", "/api/jobs?only_active=true", timeout=2.5)
        return 200 <= status < 500
    except Exception:
        return False


def _launch() -> Tuple[bool, str]:
    global _LAST_LAUNCH
    if _is_online():
        return True, "already_running"
    if not _CONFIG.start_command.strip():
        return False, "start_command_not_configured"
    with _LAUNCH_LOCK:
        now = time.time()
        if now - _LAST_LAUNCH < 5:
            return True, "launch_already_requested"
        _LAST_LAUNCH = now
        cwd = _CONFIG.start_cwd.strip() or None
        try:
            creationflags = 0
            if os.name == "nt":
                creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
            subprocess.Popen(
                _CONFIG.start_command,
                cwd=cwd,
                shell=True,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=creationflags,
            )
            return True, "launch_requested"
        except Exception as e:
            return False, str(e)


def _safe_job_id(value: str) -> Optional[str]:
    value = urllib.parse.unquote(value).strip()
    if not value or len(value) > 160:
        return None
    if any(ch in value for ch in "\\/\r\n\t"):
        return None
    return value


def handle_aitoolkit_request(handler, method: Optional[str] = None) -> bool:
    """Handle a whitelisted AI Toolkit route.

    Returns True when the request belonged to /api/aitk, including errors.
    Existing PCRemoteServer authentication should run *before* this function if the
    current server authenticates inside each do_* method.
    """
    method = (method or getattr(handler, "command", "GET")).upper()
    split = urllib.parse.urlsplit(handler.path)
    if not (split.path == PREFIX or split.path.startswith(PREFIX + "/")):
        return False

    rel = split.path[len(PREFIX):] or "/"
    query = urllib.parse.parse_qs(split.query, keep_blank_values=True)

    try:
        # Health/status is normalized by the bridge rather than blindly proxied.
        if method == "GET" and rel in {"/", "/status"}:
            online = _is_online()
            _json(handler, 200, {
                "ok": True,
                "online": online,
                "upstream": _CONFIG.base_url,
                "can_launch": bool(_CONFIG.start_command.strip()),
                "bridge_version": "1.0.0",
                "features": ["jobs", "gpu", "logs", "loss", "samples", "files", "datasets", "upload", "launch"],
            })
            return True

        if method == "POST" and rel == "/launch":
            ok, state = _launch()
            _json(handler, 200 if ok else 409, {"ok": ok, "state": state})
            return True

        if method == "POST" and rel == "/reload-config":
            reload_aitoolkit_config()
            _json(handler, 200, {"ok": True})
            return True

        if method == "GET" and rel == "/gpu":
            _proxy(handler, "GET", "/api/gpu")
            return True

        if rel == "/jobs" and method == "GET":
            suffix = ("?" + split.query) if split.query else ""
            _proxy(handler, "GET", "/api/jobs" + suffix)
            return True

        if rel == "/jobs" and method == "POST":
            body = _read_body(handler)
            _proxy(handler, "POST", "/api/jobs", body, handler.headers.get("Content-Type", "application/json"))
            return True

        if method == "GET" and rel == "/datasets":
            _proxy(handler, "GET", "/api/datasets/list")
            return True

        if method == "POST" and rel == "/datasets/create":
            body = _read_body(handler)
            _proxy(handler, "POST", "/api/datasets/create", body, handler.headers.get("Content-Type", "application/json"))
            return True

        if method == "POST" and rel == "/datasets/images":
            body = _read_body(handler)
            _proxy(handler, "POST", "/api/datasets/listImages", body, handler.headers.get("Content-Type", "application/json"))
            return True

        if method == "POST" and rel == "/datasets/upload":
            body = _read_body(handler)
            _proxy(handler, "POST", "/api/datasets/upload", body, handler.headers.get("Content-Type", "application/octet-stream"))
            return True

        # Serve media/files through AI Toolkit's own allowed-root checks.
        if method == "GET" and rel in {"/media", "/file"}:
            raw_path = (query.get("path") or [""])[0]
            if not raw_path or len(raw_path) > 4096 or "\x00" in raw_path:
                _json(handler, 400, {"error": "missing path"})
                return True
            encoded = urllib.parse.quote(raw_path, safe="")
            upstream = "/api/img/" + encoded if rel == "/media" else "/api/files/" + encoded
            if "thumb" in query and rel == "/media":
                upstream += "?thumb=1"
            _proxy_stream(handler, upstream)
            return True

        parts = [p for p in rel.split("/") if p]
        if len(parts) >= 2 and parts[0] == "jobs":
            job_id = _safe_job_id(parts[1])
            if not job_id:
                _json(handler, 400, {"error": "invalid job id"})
                return True
            qid = urllib.parse.quote(job_id, safe="")

            if len(parts) == 2 and method == "GET":
                _proxy(handler, "GET", "/api/jobs?id=" + qid)
                return True

            if len(parts) == 3:
                action = parts[2]
                if action in {"start", "stop", "save"} and method == "POST":
                    upstream_action = "save_now" if action == "save" else action
                    _proxy(handler, "GET", f"/api/jobs/{qid}/{upstream_action}")
                    return True
                if action == "delete" and method in {"POST", "DELETE"}:
                    _proxy(handler, "GET", f"/api/jobs/{qid}/delete")
                    return True
                if action == "log" and method == "GET":
                    offset = (query.get("offset") or ["0"])[0]
                    if not str(offset).isdigit():
                        offset = "0"
                    _proxy(handler, "GET", f"/api/jobs/{qid}/log?offset={offset}")
                    return True
                if action == "loss" and method == "GET":
                    allowed = []
                    for key in ("key", "limit", "since_step", "stride"):
                        if key in query:
                            allowed.append(urllib.parse.urlencode({key: query[key][0]}))
                    suffix = ("?" + "&".join(allowed)) if allowed else ""
                    _proxy(handler, "GET", f"/api/jobs/{qid}/loss{suffix}")
                    return True
                if action == "samples" and method == "GET":
                    _proxy(handler, "GET", f"/api/jobs/{qid}/samples")
                    return True
                if action == "files" and method == "GET":
                    _proxy(handler, "GET", f"/api/jobs/{qid}/files")
                    return True

        _json(handler, 404, {"error": "unknown AI Toolkit bridge route", "path": rel})
        return True
    except ValueError as e:
        _json(handler, 413 if "large" in str(e) else 400, {"error": str(e)})
        return True
    except Exception as e:
        _json(handler, 500, {"error": "bridge_error", "detail": str(e)})
        return True
