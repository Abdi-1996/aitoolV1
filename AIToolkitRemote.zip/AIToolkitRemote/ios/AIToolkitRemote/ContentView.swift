import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationStack { DashboardView() }
                .tabItem { Label("Главная", systemImage: "gauge.with.dots.needle.67percent") }
            NavigationStack { JobsView() }
                .tabItem { Label("Обучение", systemImage: "bolt.horizontal.circle") }
            NavigationStack { DatasetsView() }
                .tabItem { Label("Датасеты", systemImage: "photo.stack") }
            NavigationStack { SettingsView() }
                .tabItem { Label("Настройки", systemImage: "gearshape") }
        }
    }
}

struct StatusPill: View {
    let status: String
    var body: some View {
        Text(status.uppercased())
            .font(.caption2.bold())
            .padding(.horizontal, 8).padding(.vertical, 5)
            .background(.thinMaterial, in: Capsule())
    }
}

struct ErrorBanner: View {
    let text: String
    var body: some View {
        Label(text, systemImage: "exclamationmark.triangle.fill")
            .font(.footnote)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(10)
            .background(.red.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
    }
}

struct LoadingButtonStyle: ViewModifier {
    let busy: Bool
    func body(content: Content) -> some View { content.disabled(busy).opacity(busy ? 0.55 : 1) }
}
