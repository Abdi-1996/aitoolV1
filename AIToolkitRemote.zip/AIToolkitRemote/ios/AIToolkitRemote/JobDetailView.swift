import SwiftUI
import Charts

@MainActor
final class JobDetailModel: ObservableObject {
    @Published var job: AITJob?
    @Published var log = ""
    @Published var logOffset = 0
    @Published var loss: [LossPoint] = []
    @Published var samples: [String] = []
    @Published var files: [JobFile] = []
    @Published var error = ""
    @Published var busy = false

    func refresh(api: APIClient, id: String, full: Bool = false) async {
        do {
            async let jobCall = api.job(id: id)
            async let logCall = api.log(id: id, offset: logOffset)
            job = try await jobCall
            let chunk = try await logCall
            if chunk.reset == true { log = chunk.log } else if !chunk.log.isEmpty { log += chunk.log }
            logOffset = chunk.offset
            if full || loss.isEmpty { if let result = try? await api.loss(id: id) { loss = result.points } }
            if full || samples.isEmpty { samples = (try? await api.samples(id: id)) ?? samples }
            if full || files.isEmpty { files = (try? await api.files(id: id)) ?? files }
            error = ""
        } catch { self.error = error.localizedDescription }
    }

    func action(_ action: String, api: APIClient, id: String) async {
        busy = true; defer { busy = false }
        do {
            switch action {
            case "start": try await api.start(id: id)
            case "stop": try await api.stop(id: id)
            case "save": try await api.saveNow(id: id)
            default: break
            }
            try? await Task.sleep(for: .milliseconds(500)); await refresh(api: api, id: id, full: true)
        } catch { self.error = error.localizedDescription }
    }
}

struct JobDetailView: View {
    let jobID: String
    @EnvironmentObject private var settings: SettingsStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model = JobDetailModel()
    @State private var deleteConfirm = false
    @State private var editor = false

    var body: some View {
        List {
            if let job = model.job {
                Section {
                    HStack { VStack(alignment: .leading) { Text(job.name).font(.title3.bold()); Text(job.info).font(.caption).foregroundStyle(.secondary) }; Spacer(); StatusPill(status: job.status) }
                    if let total = job.totalSteps, total > 0 {
                        ProgressView(value: job.progress)
                        HStack { Text("\(job.step) / \(total)"); Spacer(); Text(job.speedString) }.font(.caption).foregroundStyle(.secondary)
                    }
                    HStack {
                        Button { Task { await model.action("start", api: settings.api, id: jobID) } } label: { Label("Start", systemImage: "play.fill") }.buttonStyle(.borderedProminent)
                        Button { Task { await model.action("stop", api: settings.api, id: jobID) } } label: { Label("Stop", systemImage: "stop.fill") }.buttonStyle(.bordered)
                        Button { Task { await model.action("save", api: settings.api, id: jobID) } } label: { Label("Save", systemImage: "square.and.arrow.down") }.buttonStyle(.bordered)
                    }.modifier(LoadingButtonStyle(busy: model.busy))
                }

                if !model.error.isEmpty { ErrorBanner(text: model.error).listRowSeparator(.hidden) }

                if !model.loss.isEmpty {
                    Section("Loss") {
                        Chart(model.loss) { p in LineMark(x: .value("Step", p.step), y: .value("Loss", p.value)) }
                            .frame(height: 180)
                    }
                }

                Section("Samples") {
                    if model.samples.isEmpty { Text("Пока нет samples").foregroundStyle(.secondary) }
                    ScrollView(.horizontal) {
                        LazyHStack(spacing: 10) {
                            ForEach(model.samples, id: \.self) { path in RemoteMediaView(path: path).frame(width: 150, height: 150) }
                        }
                    }.scrollIndicators(.hidden)
                }

                Section("Файлы LoRA / checkpoint") {
                    if model.files.isEmpty { Text("Файлов пока нет").foregroundStyle(.secondary) }
                    ForEach(model.files) { file in JobFileRow(file: file) }
                }

                Section("Live log") {
                    ScrollView(.horizontal) {
                        Text(model.log.isEmpty ? "Лог пока пуст" : model.log)
                            .font(.system(.caption2, design: .monospaced)).textSelection(.enabled)
                    }.frame(maxHeight: 300)
                }

                Section {
                    Button("Изменить конфиг JSON", systemImage: "slider.horizontal.3") { editor = true }
                    Button("Удалить задание и training folder", systemImage: "trash", role: .destructive) { deleteConfirm = true }
                }
            } else if !model.error.isEmpty { ErrorBanner(text: model.error) }
        }
        .navigationTitle("Job")
        .navigationBarTitleDisplayMode(.inline)
        .refreshable { await model.refresh(api: settings.api, id: jobID, full: true) }
        .task(id: settings.serverURL) {
            var tick = 0
            while !Task.isCancelled {
                await model.refresh(api: settings.api, id: jobID, full: tick % 4 == 0)
                tick += 1
                try? await Task.sleep(for: .seconds(max(1, settings.refreshSeconds)))
            }
        }
        .sheet(isPresented: $editor) { if let job = model.job { NavigationStack { JobEditorView(job: job) { updated in model.job = updated; editor = false } } } }
        .confirmationDialog("Удалить это задание?", isPresented: $deleteConfirm, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { Task { do { try await settings.api.delete(id: jobID); dismiss() } catch { model.error = error.localizedDescription } } }
        } message: { Text("AI Toolkit удалит запись задания и его training folder.") }
    }
}

struct JobEditorView: View {
    let job: AITJob
    let onSaved: (AITJob) -> Void
    @EnvironmentObject private var settings: SettingsStore
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    @State private var gpuIds: String
    @State private var config: String
    @State private var error = ""
    @State private var busy = false

    init(job: AITJob, onSaved: @escaping (AITJob) -> Void) {
        self.job = job; self.onSaved = onSaved
        _name = State(initialValue: job.name); _gpuIds = State(initialValue: job.gpuIds)
        if let data = job.jobConfig.data(using: .utf8), let obj = try? JSONSerialization.jsonObject(with: data), let pretty = try? JSONSerialization.data(withJSONObject: obj, options: [.prettyPrinted, .sortedKeys]) {
            _config = State(initialValue: String(data: pretty, encoding: .utf8) ?? job.jobConfig)
        } else { _config = State(initialValue: job.jobConfig) }
    }

    var body: some View {
        Form {
            TextField("Название", text: $name)
            TextField("GPU IDs", text: $gpuIds).textInputAutocapitalization(.never)
            Section("job_config JSON") { TextEditor(text: $config).font(.system(.caption, design: .monospaced)).frame(minHeight: 360) }
            if !error.isEmpty { ErrorBanner(text: error) }
        }
        .navigationTitle("Конфиг")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("Сохранить") { Task { await save() } }.disabled(busy) }
        }
    }

    @MainActor private func save() async {
        busy = true; defer { busy = false }
        do { let updated = try await settings.api.saveJob(job, name: name, gpuIds: gpuIds, configText: config); onSaved(updated) }
        catch { self.error = error.localizedDescription }
    }
}

struct RemoteMediaView: View {
    let path: String
    @EnvironmentObject private var settings: SettingsStore
    @State private var image: UIImage?
    @State private var failed = false
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12).fill(.quaternary)
            if let image { Image(uiImage: image).resizable().scaledToFill().clipShape(RoundedRectangle(cornerRadius: 12)) }
            else if failed { Image(systemName: "photo.badge.exclamationmark").foregroundStyle(.secondary) }
            else { ProgressView() }
        }.task(id: path + settings.serverURL) {
            do { let data = try await settings.api.mediaData(path: path, thumb: true); image = UIImage(data: data); failed = image == nil }
            catch { failed = true }
        }
    }
}

struct JobFileRow: View {
    let file: JobFile
    @EnvironmentObject private var settings: SettingsStore
    @State private var localURL: URL?
    @State private var busy = false
    @State private var error = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Image(systemName: "doc.zipper")
                VStack(alignment: .leading) { Text(file.name).lineLimit(1); Text(ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file)).font(.caption).foregroundStyle(.secondary) }
                Spacer()
                if let localURL { ShareLink(item: localURL) { Image(systemName: "square.and.arrow.up") } }
                else { Button { Task { await download() } } label: { if busy { ProgressView() } else { Image(systemName: "arrow.down.circle") } } }
            }
            if !error.isEmpty { Text(error).font(.caption2).foregroundStyle(.red) }
        }
    }
    @MainActor private func download() async { busy = true; defer { busy = false }; do { localURL = try await settings.api.downloadFile(path: file.path) } catch { self.error = error.localizedDescription } }
}
