import SwiftUI

@MainActor
final class JobsModel: ObservableObject {
    @Published var jobs: [AITJob] = []
    @Published var error = ""
    @Published var activeOnly = false
    func refresh(api: APIClient) async {
        do { jobs = try await api.jobs(activeOnly: activeOnly); error = "" }
        catch { self.error = error.localizedDescription }
    }
}

struct JobsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @StateObject private var model = JobsModel()
    @State private var newJobShown = false

    var body: some View {
        List {
            if !model.error.isEmpty { ErrorBanner(text: model.error).listRowSeparator(.hidden) }
            ForEach(model.jobs) { job in
                NavigationLink { JobDetailView(jobID: job.id) } label: { JobRow(job: job) }
            }
        }
        .overlay { if model.jobs.isEmpty && model.error.isEmpty { ContentUnavailableView("Нет заданий", systemImage: "tray") } }
        .navigationTitle("Обучение")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { model.activeOnly.toggle(); Task { await model.refresh(api: settings.api) } } label: {
                    Image(systemName: model.activeOnly ? "bolt.fill" : "bolt")
                }
                Button { newJobShown = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $newJobShown) { NavigationStack { NewJobView { _ in Task { await model.refresh(api: settings.api) } } } }
        .refreshable { await model.refresh(api: settings.api) }
        .task(id: "\(settings.serverURL)-\(model.activeOnly)") {
            while !Task.isCancelled {
                await model.refresh(api: settings.api)
                try? await Task.sleep(for: .seconds(max(1.5, settings.refreshSeconds)))
            }
        }
    }
}

struct JobRow: View {
    let job: AITJob
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack { Text(job.name).font(.headline).lineLimit(1); Spacer(); StatusPill(status: job.status) }
            if let total = job.totalSteps, total > 0 {
                ProgressView(value: job.progress)
                HStack { Text("Шаг \(job.step) / \(total)"); Spacer(); Text(job.speedString) }.font(.caption).foregroundStyle(.secondary)
            } else if !job.info.isEmpty {
                Text(job.info).font(.caption).foregroundStyle(.secondary).lineLimit(2)
            }
        }.padding(.vertical, 3)
    }
}
