import SwiftUI
import UniformTypeIdentifiers

struct NewJobView: View {
    let onCreated: (AITJob) -> Void
    @EnvironmentObject private var settings: SettingsStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var gpuIds = "0"
    @State private var jobType = "train"
    @State private var config = "{\n  \"job\": \"extension\",\n  \"config\": {\n    \"name\": \"my_lora\",\n    \"process\": []\n  }\n}"
    @State private var error = ""
    @State private var busy = false
    @State private var importing = false

    var body: some View {
        Form {
            Section("Job") {
                TextField("Название задания", text: $name)
                TextField("GPU IDs", text: $gpuIds).textInputAutocapitalization(.never)
                Picker("Тип", selection: $jobType) {
                    Text("Training").tag("train")
                    Text("Caption").tag("caption")
                }
            }
            Section {
                Button("Импортировать job_config JSON", systemImage: "doc.badge.plus") { importing = true }
                TextEditor(text: $config).font(.system(.caption, design: .monospaced)).frame(minHeight: 360)
            } header: { Text("job_config") } footer: {
                Text("Можно вставить/импортировать конфиг из существующего AI Toolkit. Приложение отправляет его без изменения структуры.")
            }
            if !error.isEmpty { ErrorBanner(text: error) }
        }
        .navigationTitle("Новое обучение")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("Создать") { Task { await create() } }.disabled(busy || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json, .plainText]) { result in
            do {
                let url = try result.get()
                guard url.startAccessingSecurityScopedResource() else { throw APIError(message: "Нет доступа к файлу") }
                defer { url.stopAccessingSecurityScopedResource() }
                config = try String(contentsOf: url, encoding: .utf8)
            } catch { self.error = error.localizedDescription }
        }
    }

    @MainActor private func create() async {
        busy = true; defer { busy = false }
        do {
            let job = try await settings.api.createJob(name: name.trimmingCharacters(in: .whitespacesAndNewlines), gpuIds: gpuIds, jobType: jobType, configText: config)
            onCreated(job); dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
