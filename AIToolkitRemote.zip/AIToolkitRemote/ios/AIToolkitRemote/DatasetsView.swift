import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

@MainActor
final class DatasetsModel: ObservableObject {
    @Published var datasets: [String] = []
    @Published var error = ""
    @Published var busy = false

    func refresh(api: APIClient) async {
        do { datasets = try await api.datasets().sorted(); error = "" }
        catch { self.error = error.localizedDescription }
    }

    func create(name: String, api: APIClient) async -> Bool {
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        busy = true; defer { busy = false }
        do { _ = try await api.createDataset(name: name); await refresh(api: api); return true }
        catch { self.error = error.localizedDescription; return false }
    }
}

struct DatasetsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @StateObject private var model = DatasetsModel()
    @State private var createShown = false
    @State private var newName = ""

    var body: some View {
        List {
            if !model.error.isEmpty { ErrorBanner(text: model.error).listRowSeparator(.hidden) }
            ForEach(model.datasets, id: \.self) { dataset in
                NavigationLink { DatasetDetailView(dataset: dataset) } label: {
                    Label(dataset, systemImage: "folder.fill")
                }
            }
        }
        .overlay { if model.datasets.isEmpty && model.error.isEmpty { ContentUnavailableView("Нет датасетов", systemImage: "photo.stack") } }
        .navigationTitle("Датасеты")
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { newName = ""; createShown = true } label: { Image(systemName: "plus") } } }
        .refreshable { await model.refresh(api: settings.api) }
        .task(id: settings.serverURL) { await model.refresh(api: settings.api) }
        .alert("Новый датасет", isPresented: $createShown) {
            TextField("Название", text: $newName)
            Button("Создать") { Task { if await model.create(name: newName, api: settings.api) { createShown = false } } }
            Button("Отмена", role: .cancel) { }
        }
    }
}

@MainActor
final class DatasetDetailModel: ObservableObject {
    @Published var images: [String] = []
    @Published var root = ""
    @Published var error = ""
    @Published var busy = false

    func refresh(name: String, api: APIClient) async {
        do { let e = try await api.datasetImages(name: name); images = e.images; root = e.root ?? ""; error = "" }
        catch { self.error = error.localizedDescription }
    }

    func upload(name: String, items: [PhotosPickerItem], api: APIClient) async {
        guard !items.isEmpty else { return }
        busy = true; defer { busy = false }
        do {
            var upload: [UploadImage] = []
            for (index, item) in items.enumerated() {
                guard let data = try await item.loadTransferable(type: Data.self) else { continue }
                let type = item.supportedContentTypes.first
                let ext = type?.preferredFilenameExtension ?? "jpg"
                let mime = type?.preferredMIMEType ?? "image/jpeg"
                upload.append(UploadImage(data: data, filename: String(format: "iphone_%04d.%@", index + 1, ext), mimeType: mime))
            }
            guard !upload.isEmpty else { throw APIError(message: "Не удалось прочитать выбранные фото") }
            try await api.upload(dataset: name, images: upload)
            await refresh(name: name, api: api)
        } catch { self.error = error.localizedDescription }
    }
}

struct DatasetDetailView: View {
    let dataset: String
    @EnvironmentObject private var settings: SettingsStore
    @StateObject private var model = DatasetDetailModel()
    @State private var pickerItems: [PhotosPickerItem] = []

    private func fullPath(_ relative: String) -> String {
        if model.root.isEmpty { return relative }
        if model.root.hasSuffix("/") || model.root.hasSuffix("\\") { return model.root + relative }
        let sep = model.root.contains("\\") ? "\\" : "/"
        return model.root + sep + relative
    }

    var body: some View {
        List {
            if !model.error.isEmpty { ErrorBanner(text: model.error).listRowSeparator(.hidden) }
            Section {
                PhotosPicker(selection: $pickerItems, maxSelectionCount: 100, matching: .images) {
                    HStack { Label("Добавить фото с iPhone", systemImage: "photo.badge.plus"); Spacer(); if model.busy { ProgressView() } }
                }.disabled(model.busy)
            }
            Section("Фото: \(model.images.count)") {
                if model.images.isEmpty { Text("Папка пустая").foregroundStyle(.secondary) }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 82), spacing: 8)], spacing: 8) {
                    ForEach(model.images, id: \.self) { image in
                        RemoteMediaView(path: fullPath(image)).frame(height: 86)
                    }
                }.padding(.vertical, 4)
            }
        }
        .navigationTitle(dataset)
        .navigationBarTitleDisplayMode(.inline)
        .refreshable { await model.refresh(name: dataset, api: settings.api) }
        .task(id: settings.serverURL) { await model.refresh(name: dataset, api: settings.api) }
        .onChange(of: pickerItems) { _, items in
            guard !items.isEmpty else { return }
            Task { await model.upload(name: dataset, items: items, api: settings.api); pickerItems = [] }
        }
    }
}
