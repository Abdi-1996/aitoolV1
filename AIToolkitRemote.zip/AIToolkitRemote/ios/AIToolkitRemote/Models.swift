import Foundation

struct BridgeStatus: Codable {
    let ok: Bool
    let online: Bool
    let upstream: String?
    let canLaunch: Bool?
    let bridgeVersion: String?
    let features: [String]?

    enum CodingKeys: String, CodingKey {
        case ok, online, upstream, features
        case canLaunch = "can_launch"
        case bridgeVersion = "bridge_version"
    }
}

struct JobsEnvelope: Codable { let jobs: [AITJob] }

struct AITJob: Codable, Identifiable, Hashable {
    let id: String
    var name: String
    var gpuIds: String
    var jobConfig: String
    var createdAt: String?
    var updatedAt: String?
    var status: String
    var stop: Bool
    var step: Int
    var totalSteps: Int?
    var info: String
    var speedString: String
    var queuePosition: Int
    var pid: Int?
    var jobType: String
    var jobRef: String?
    var saveNow: Bool

    enum CodingKeys: String, CodingKey {
        case id, name, status, stop, step, info, pid
        case gpuIds = "gpu_ids"
        case jobConfig = "job_config"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case totalSteps = "total_steps"
        case speedString = "speed_string"
        case queuePosition = "queue_position"
        case jobType = "job_type"
        case jobRef = "job_ref"
        case saveNow = "save_now"
    }

    var progress: Double {
        guard let totalSteps, totalSteps > 0 else { return 0 }
        return min(1, max(0, Double(step) / Double(totalSteps)))
    }
    var isActive: Bool { ["running", "queued", "stopping"].contains(status.lowercased()) }
}

struct GPUEnvelope: Codable { let hasNvidiaSmi: Bool?; let gpus: [GPUInfo]; let error: String? }
struct GPUInfo: Codable, Identifiable {
    var id: Int { index }
    let index: Int
    let name: String
    let driverVersion: String?
    let temperature: Double?
    let utilization: GPUUtilization?
    let memory: GPUMemory?
    let power: GPUPower?
    let fan: GPUFan?
}
struct GPUUtilization: Codable { let gpu: Double?; let memory: Double? }
struct GPUMemory: Codable { let total: Double?; let free: Double?; let used: Double? }
struct GPUPower: Codable { let draw: Double?; let limit: Double? }
struct GPUFan: Codable { let speed: Double? }

struct LogEnvelope: Codable { let log: String; let offset: Int; let reset: Bool? }
struct SamplesEnvelope: Codable { let samples: [String] }
struct JobFilesEnvelope: Codable { let files: [JobFile] }
struct JobFile: Codable, Identifiable, Hashable {
    var id: String { path }
    let path: String
    let size: Int64
    var name: String { path.replacingOccurrences(of: "\\", with: "/").split(separator: "/").last.map(String.init) ?? path }
}

struct LossEnvelope: Codable {
    let key: String?
    let keys: [String]?
    let points: [LossPoint]
}
struct LossPoint: Codable, Identifiable {
    var id: String { "\(step)-\(wallTime ?? 0)-\(value)" }
    let step: Int
    let wallTime: Double?
    let value: Double
    enum CodingKeys: String, CodingKey { case step, value; case wallTime = "wall_time" }
}

struct DatasetImagesEnvelope: Codable { let root: String?; let images: [String] }
struct DatasetCreateResponse: Codable { let success: Bool?; let name: String?; let error: String? }
struct LaunchResponse: Codable { let ok: Bool; let state: String }
struct GenericResponse: Codable { let ok: Bool?; let error: String?; let state: String? }

// Encodable representation of arbitrary JSON from a job_config string.
enum JSONValue: Codable, Hashable {
    case string(String), number(Double), bool(Bool), object([String: JSONValue]), array([JSONValue]), null

    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { self = .null }
        else if let v = try? c.decode(Bool.self) { self = .bool(v) }
        else if let v = try? c.decode(Double.self) { self = .number(v) }
        else if let v = try? c.decode(String.self) { self = .string(v) }
        else if let v = try? c.decode([String: JSONValue].self) { self = .object(v) }
        else { self = .array(try c.decode([JSONValue].self)) }
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch self {
        case .string(let v): try c.encode(v)
        case .number(let v): try c.encode(v)
        case .bool(let v): try c.encode(v)
        case .object(let v): try c.encode(v)
        case .array(let v): try c.encode(v)
        case .null: try c.encodeNil()
        }
    }
}
