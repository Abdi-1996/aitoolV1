import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @State private var testText = ""
    @State private var testing = false

    var body: some View {
        Form {
            Section("PC Remote Server") {
                TextField("http://100.x.x.x:порт", text: $settings.serverURL)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                SecureField("Access key (если используется)", text: $settings.accessKey)
                Button { Task { await test() } } label: {
                    HStack { Label("Проверить подключение", systemImage: "network"); Spacer(); if testing { ProgressView() } }
                }
                if !testText.isEmpty { Text(testText).font(.footnote).foregroundStyle(testText.hasPrefix("✓") ? Color.gray : Color.red) }
            }
            Section("Обновление") {
                HStack { Text("Интервал"); Spacer(); Text("\(settings.refreshSeconds, specifier: "%.1f") с").foregroundStyle(.secondary) }
                Slider(value: $settings.refreshSeconds, in: 1...10, step: 0.5)
            }
            Section("Архитектура") {
                LabeledContent("iPhone", value: "AI Toolkit Remote")
                LabeledContent("PC", value: "PCRemoteServer 6.x")
                LabeledContent("AI Toolkit", value: "127.0.0.1:8675")
                Text("Порт AI Toolkit не нужно открывать в LAN или Tailscale. Наружу выходит только PC Remote Server.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle("Настройки")
    }

    @MainActor private func test() async {
        testing = true; defer { testing = false }
        do {
            let s = try await settings.api.status()
            testText = s.online ? "✓ Server и AI Toolkit доступны" : "✓ Server доступен, AI Toolkit сейчас выключен"
        } catch { testText = "Ошибка: \(error.localizedDescription)" }
    }
}
