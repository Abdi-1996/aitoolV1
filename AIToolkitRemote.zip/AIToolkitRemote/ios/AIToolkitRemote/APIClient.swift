import Foundation
import UIKit

struct APIError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

struct UploadImage {
    let data: Data
    let filename: String
    let mimeType: String
}

struct APIClient {
    let baseURLString: String
    let accessKey: String
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()

    private var baseURL: URL? {
        var text = baseURLString.trimmingCharacters(in: .whitespacesAndNewlines)
        while text.hasSuffix("/") { text.removeLast() }
        return URL(string: text)
    }

    func url(path: String, queryItems: [URLQueryItem] = []) throws -> URL {
        guard let baseURL else { throw APIError(message: "Неверный адрес сервера") }
        var components = URLComponents(url: baseURL.appendingPathComponent(path), resolvingAgainstBaseURL: false)
        if !queryItems.isEmpty { components?.queryItems = queryItems }
        guard let result = components?.url else { throw APIError(message: "Неверный URL") }
        return result
    }

    private func request(path: String, method: String = "GET", query: [URLQueryItem] = [], body: Data? = nil, contentType: String? = nil) throws -> URLRequest {
        var req = URLRequest(url: try url(path: path, queryItems: query))
        req.httpMethod = method
        req.timeoutInterval = 30
        req.cachePolicy = .reloadIgnoringLocalCacheData
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if !accessKey.isEmpty {
            req.setValue(accessKey, forHTTPHeaderField: "X-PCRemote-Key")
            req.setValue("Bearer \(accessKey)", forHTTPHeaderField: "Authorization")
        }
        if let contentType { req.setValue(contentType, forHTTPHeaderField: "Content-Type") }
        req.httpBody = body
        return req
    }

    private func send<T: Decodable>(_ type: T.Type, path: String, method: String = "GET", query: [URLQueryItem] = [], body: Data? = nil, contentType: String? = nil) async throws -> T {
        let req = try request(path: path, method: method, query: query, body: body, contentType: contentType)
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw APIError(message: "Нет HTTP ответа") }
        guard (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw APIError(message: text)
        }
        do { return try decoder.decode(type, from: data) }
        catch { throw APIError(message: "Ошибка ответа сервера: \(error.localizedDescription)") }
    }

    func status() async throws -> BridgeStatus { try await send(BridgeStatus.self, path: "api/aitk/status") }
    func launch() async throws -> LaunchResponse { try await send(LaunchResponse.self, path: "api/aitk/launch", method: "POST") }
    func gpu() async throws -> GPUEnvelope { try await send(GPUEnvelope.self, path: "api/aitk/gpu") }
    func jobs(activeOnly: Bool = false) async throws -> [AITJob] {
        let query = activeOnly ? [URLQueryItem(name: "only_active", value: "true")] : []
        return (try await send(JobsEnvelope.self, path: "api/aitk/jobs", query: query)).jobs
    }
    func job(id: String) async throws -> AITJob { try await send(AITJob.self, path: "api/aitk/jobs/\(id)") }
    func start(id: String) async throws { let _: GenericResponse = try await send(GenericResponse.self, path: "api/aitk/jobs/\(id)/start", method: "POST") }
    func stop(id: String) async throws { let _: GenericResponse = try await send(GenericResponse.self, path: "api/aitk/jobs/\(id)/stop", method: "POST") }
    func saveNow(id: String) async throws { let _: GenericResponse = try await send(GenericResponse.self, path: "api/aitk/jobs/\(id)/save", method: "POST") }
    func delete(id: String) async throws { let _: GenericResponse = try await send(GenericResponse.self, path: "api/aitk/jobs/\(id)/delete", method: "POST") }

    func log(id: String, offset: Int) async throws -> LogEnvelope {
        try await send(LogEnvelope.self, path: "api/aitk/jobs/\(id)/log", query: [URLQueryItem(name: "offset", value: String(offset))])
    }
    func loss(id: String, limit: Int = 500) async throws -> LossEnvelope {
        try await send(LossEnvelope.self, path: "api/aitk/jobs/\(id)/loss", query: [URLQueryItem(name: "limit", value: String(limit))])
    }
    func samples(id: String) async throws -> [String] { (try await send(SamplesEnvelope.self, path: "api/aitk/jobs/\(id)/samples")).samples }
    func files(id: String) async throws -> [JobFile] { (try await send(JobFilesEnvelope.self, path: "api/aitk/jobs/\(id)/files")).files }

    func createJob(name: String, gpuIds: String, jobType: String = "train", configText: String) async throws -> AITJob {
        guard let data = configText.data(using: .utf8) else { throw APIError(message: "Конфиг не UTF-8") }
        let config = try decoder.decode(JSONValue.self, from: data)
        struct Payload: Encodable {
            let name: String; let gpu_ids: String; let job_config: JSONValue; let job_type: String
        }
        let payload = Payload(name: name, gpu_ids: gpuIds, job_config: config, job_type: jobType)
        return try await send(AITJob.self, path: "api/aitk/jobs", method: "POST", body: try encoder.encode(payload), contentType: "application/json")
    }

    func saveJob(_ job: AITJob, name: String, gpuIds: String, configText: String) async throws -> AITJob {
        guard let data = configText.data(using: .utf8) else { throw APIError(message: "Конфиг не UTF-8") }
        let config = try decoder.decode(JSONValue.self, from: data)
        struct Payload: Encodable {
            let id: String; let name: String; let gpu_ids: String; let job_config: JSONValue; let job_ref: String?; let job_type: String
        }
        let payload = Payload(id: job.id, name: name, gpu_ids: gpuIds, job_config: config, job_ref: job.jobRef, job_type: job.jobType)
        return try await send(AITJob.self, path: "api/aitk/jobs", method: "POST", body: try encoder.encode(payload), contentType: "application/json")
    }

    func datasets() async throws -> [String] { try await send([String].self, path: "api/aitk/datasets") }
    func createDataset(name: String) async throws -> DatasetCreateResponse {
        struct P: Encodable { let name: String }
        return try await send(DatasetCreateResponse.self, path: "api/aitk/datasets/create", method: "POST", body: try encoder.encode(P(name: name)), contentType: "application/json")
    }
    func datasetImages(name: String) async throws -> DatasetImagesEnvelope {
        struct P: Encodable { let datasetName: String }
        return try await send(DatasetImagesEnvelope.self, path: "api/aitk/datasets/images", method: "POST", body: try encoder.encode(P(datasetName: name)), contentType: "application/json")
    }

    func upload(dataset: String, images: [UploadImage]) async throws {
        let boundary = "AITK-\(UUID().uuidString)"
        var data = Data()
        func append(_ text: String) { data.append(text.data(using: .utf8)!) }
        for image in images {
            append("--\(boundary)\r\n")
            append("Content-Disposition: form-data; name=\"files\"; filename=\"\(image.filename)\"\r\n")
            append("Content-Type: \(image.mimeType)\r\n\r\n")
            data.append(image.data); append("\r\n")
        }
        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"datasetName\"\r\n\r\n")
        append(dataset); append("\r\n--\(boundary)--\r\n")
        let _: GenericResponse = try await send(GenericResponse.self, path: "api/aitk/datasets/upload", method: "POST", body: data, contentType: "multipart/form-data; boundary=\(boundary)")
    }

    func mediaData(path: String, thumb: Bool = false) async throws -> Data {
        var q = [URLQueryItem(name: "path", value: path)]
        if thumb { q.append(URLQueryItem(name: "thumb", value: "1")) }
        let req = try request(path: "api/aitk/media", query: q)
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw APIError(message: "Не удалось загрузить media") }
        return data
    }

    func downloadFile(path: String) async throws -> URL {
        let req = try request(path: "api/aitk/file", query: [URLQueryItem(name: "path", value: path)])
        let (tmp, response) = try await URLSession.shared.download(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw APIError(message: "Не удалось скачать файл") }
        let name = path.replacingOccurrences(of: "\\", with: "/").split(separator: "/").last.map(String.init) ?? "download.bin"
        let dst = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: dst)
        try FileManager.default.moveItem(at: tmp, to: dst)
        return dst
    }
}
