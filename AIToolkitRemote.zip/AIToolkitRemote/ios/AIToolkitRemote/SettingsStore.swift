import SwiftUI

@MainActor
final class SettingsStore: ObservableObject {
    @Published var serverURL: String { didSet { UserDefaults.standard.set(serverURL, forKey: "serverURL") } }
    @Published var accessKey: String { didSet { UserDefaults.standard.set(accessKey, forKey: "accessKey") } }
    @Published var refreshSeconds: Double { didSet { UserDefaults.standard.set(refreshSeconds, forKey: "refreshSeconds") } }

    init() {
        serverURL = UserDefaults.standard.string(forKey: "serverURL") ?? "http://192.168.1.100:8000"
        accessKey = UserDefaults.standard.string(forKey: "accessKey") ?? ""
        let saved = UserDefaults.standard.double(forKey: "refreshSeconds")
        refreshSeconds = saved > 0 ? saved : 2.0
    }

    var api: APIClient { APIClient(baseURLString: serverURL, accessKey: accessKey) }
}
