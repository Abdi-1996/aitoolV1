import SwiftUI

@MainActor
final class DashboardModel: ObservableObject {
    @Published var status: BridgeStatus?
    @Published var gpus: [GPUInfo] = []
    @Published var activeJobs: [AITJob] = []
    @Published var error = ""
    @Published var busy = false

    func refresh(api: APIClient) async {
        do {
            let s = try await api.status()
            status = s
            guard s.online else { gpus = []; activeJobs = []; return }
            async let gpuCall = api.gpu()
            async let jobsCall = api.jobs(activeOnly: true)
            let gpuResult = try await gpuCall
            gpus = gpuResult.gpus
            activeJobs = try await jobsCall
            error = ""
        } catch { self.error = error.localizedDescription }
    }

    func launch(api: APIClient) async {
        busy = true; defer { busy = false }
        do { _ = try await api.launch(); try? await Task.sleep(for: .seconds(2)); await refresh(api: api) }
        catch { self.error = error.localizedDescription }
    }
}

struct DashboardView: View {
    @EnvironmentObject private var settings: SettingsStore
    @StateObject private var model = DashboardModel()

    var body: some View {
        List {
            Section {
                HStack(spacing: 12) {
                    Image(systemName: model.status?.online == true ? "checkmark.circle.fill" : "bolt.slash.circle.fill")
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(model.status?.online == true ? "AI Toolkit подключён" : "AI Toolkit не запущен").font(.headline)
                        Text(model.status?.upstream ?? "через PC Remote Server").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                if model.status?.online != true, model.status?.canLaunch == true {
                    Button { Task { await model.launch(api: settings.api) } } label: {
                        Label("Запустить AI Toolkit на ПК", systemImage: "play.fill")
                    }.modifier(LoadingButtonStyle(busy: model.busy))
                }
            }

            if !model.error.isEmpty { ErrorBanner(text: model.error).listRowSeparator(.hidden) }

            if model.status?.online == true {
                Section("GPU") {
                    if model.gpus.isEmpty { Text("GPU данные недоступны").foregroundStyle(.secondary) }
                    ForEach(model.gpus) { gpu in GPUCard(gpu: gpu) }
                }
                Section("Активные задания") {
                    if model.activeJobs.isEmpty { Text("Сейчас обучение не запущено").foregroundStyle(.secondary) }
                    ForEach(model.activeJobs) { job in
                        NavigationLink { JobDetailView(jobID: job.id) } label: { JobRow(job: job) }
                    }
                }
            }
        }
        .navigationTitle("AI Toolkit")
        .refreshable { await model.refresh(api: settings.api) }
        .task(id: settings.serverURL) {
            while !Task.isCancelled {
                await model.refresh(api: settings.api)
                try? await Task.sleep(for: .seconds(max(1, settings.refreshSeconds)))
            }
        }
    }
}

struct GPUCard: View {
    let gpu: GPUInfo
    private func mbToGB(_ mb: Double?) -> String { String(format: "%.1f", (mb ?? 0) / 1024.0) }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack { Text(gpu.name).font(.headline); Spacer(); Text("GPU \(gpu.index)").font(.caption).foregroundStyle(.secondary) }
            HStack {
                Label("\(Int(gpu.utilization?.gpu ?? 0))%", systemImage: "speedometer")
                Spacer()
                Label("\(mbToGB(gpu.memory?.used))/\(mbToGB(gpu.memory?.total)) GB", systemImage: "memorychip")
                Spacer()
                Label("\(Int(gpu.temperature ?? 0))°C", systemImage: "thermometer.medium")
            }.font(.caption)
            ProgressView(value: min(100, gpu.memory?.used ?? 0), total: max(1, gpu.memory?.total ?? 1))
        }.padding(.vertical, 4)
    }
}
